A Webextension for CSDN website.
Auto conver csdn-pages to reader view in firefox.
